window.onload = async function(){
    console.log("task 7-8");

}